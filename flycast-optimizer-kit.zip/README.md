# Flycast cast optimiser — Codespaces kit

Finds the easiest hand motion that lands the fly softly at a target distance.

## Files
- `build-sim.py`   slices the physics core out of `index.html` into `sim.mjs`
- `three-stub.mjs` stand-in for the three.js maths the sim uses
- `opt.mjs`        stroke parameterisation, cost function, ready position
- `run_target.mjs` two-stage search for ONE target
- `grid.mjs`       loops run_target over many targets, writes `casts.json`
- `record_best.mjs` dumps geometry for the best cast
- `render.py`      turns that into a four-view MP4

## Setup
Put every file in the SAME folder as `index.html` (repo root is fine), then:

```
python3 build-sim.py          # regenerate sim.mjs — do this after ANY index.html edit
node run_target.mjs 10 2      # 10 m target, 2 false-cast cycles
```

## Full grid
```
GENS1=18 GENS2=18 LAM=16 node grid.mjs 6,8,10,12,14
```
Resumable — it skips cells already in `casts.json`, so you can stop and restart.
Budget roughly 30-45 min per cell, so 15 cells is an overnight run.

## Video of a result
```
node record_best.mjs
pip install pillow          # only needed once
python3 render.py           # writes flycast-sim.mp4
```

## Known issues to watch
- Tip deflection should land in 45-75 cm for a 9 ft 5wt. Current results run
  100-150 cm, which is not yet a human motion. The gate is in `opt.mjs` under
  `infeasible` — tighten it if results stay outside the band.
- Accuracy is a hard constraint (default 1 m); effort is what gets minimised
  inside it. Change `opts.tol` to tighten.
