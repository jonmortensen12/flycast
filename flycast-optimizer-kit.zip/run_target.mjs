import { BOUNDS, robustCost, evaluate, cost, peakEffort, seedFor } from './opt.mjs';
import { writeFileSync } from 'fs';
const lo=BOUNDS.map(b=>b[1]), hi=BOUNDS.map(b=>b[2]);
const clamp=v=>v.map((x,i)=>Math.max(lo[i],Math.min(hi[i],x)));
const obj=v=>Object.fromEntries(BOUNDS.map((b,i)=>[b[0],v[i]]));
let sd=987; const rnd=()=>{sd=(sd*1103515245+12345)&0x7fffffff;return sd/0x7fffffff;};
const gauss=()=>{let u=0,v=0;while(!u)u=rnd();while(!v)v=rnd();return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v);};

function stage(mean,sig,target,{gens,lam,mu,ns,st,label}){
  let best=null;
  for(let g=0;g<gens;g++){
    const pop=[];
    for(let i=0;i<lam;i++){
      const v=(g===0&&i===0)?mean.slice():clamp(mean.map((m,j)=>m+sig[j]*gauss()));
      const c=robustCost(v,target,{stage:st},ns);
      pop.push({v,c}); if(!best||c<best.c) best={v:v.slice(),c};
    }
    pop.sort((a,b)=>a.c-b.c);
    const el=pop.slice(0,mu);
    mean=mean.map((_,j)=>el.reduce((s,p)=>s+p.v[j],0)/mu);
    sig=sig.map((s,j)=>{
      const sdv=Math.sqrt(el.reduce((a,p)=>a+(p.v[j]-mean[j])**2,0)/mu);
      return Math.max((hi[j]-lo[j])*0.010,0.5*s+0.8*sdv);
    });
    console.log(`  ${label} gen ${g+1}/${gens}  best ${best.c.toFixed(3)}`);
  }
  return {mean,sig,best};
}

const D=+process.argv[2]||10;
const FIXC=+process.argv[3]||0;   // fix the cycle count if given
const target={x:0.28,z:0.10-D};
console.log(`target ${D} m downrange (water surface, ~1.15 m below the hand)\n`);
let seed=seedFor(target);
if(FIXC) seed[8]=FIXC;
let sig=[1.8,16,0.08,0.18,16,0.07,0.22,7,FIXC?0.0001:0.7];
const t0=Date.now();
const G1=+(process.env.GENS1||18), G2=+(process.env.GENS2||18), LAM=+(process.env.LAM||16);
let s1=stage(seed,sig,target,{gens:G1,lam:LAM,mu:Math.max(3,LAM>>2),ns:1,st:1,label:'S1'});
let s2=stage(s1.best.v,s1.sig.map(x=>x*0.5),target,{gens:G2,lam:LAM,mu:Math.max(3,LAM>>2),ns:3,st:2,label:'S2'});
const P=obj(s2.best.v);
const r=evaluate(P,target,{});
console.log('\nBEST PARAMETERS');
for(const k in P) console.log(`  ${k.padEnd(10)} ${P[k].toFixed(2)}`);
if(r){
  const miss=Math.hypot(r.landed.x-target.x,r.landed.z-target.z);
  console.log(`\n  miss ${miss.toFixed(2)} m   impact ${r.landed.v.toFixed(2)} m/s`);
  console.log(`  butt ${r.peakW.toFixed(0)} deg/s   hand ${r.peakHand.toFixed(2)} m/s   defl ${(r.maxDefl*100).toFixed(0)} cm`);
  console.log(`  effort ${peakEffort(r).toFixed(2)}   cycles ${Math.round(P.cycles)}   back ${r.backMost.toFixed(1)} m   high ${r.flyHigh.toFixed(1)} m   loop ${r.loopSeen}`);
}
writeFileSync('best_target.json',JSON.stringify({target,P},null,1));
console.log(`\n  ${((Date.now()-t0)/1000).toFixed(0)} s`);
