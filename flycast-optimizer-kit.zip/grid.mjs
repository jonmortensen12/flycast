/* Run the whole grid. Three searches per target (one per cycle count), keeping
   the best. Writes casts.json — the table the game would ship and interpolate. */
import { spawnSync } from 'child_process';
import { writeFileSync, readFileSync, existsSync } from 'fs';
const DISTANCES = (process.argv[2]||'6,8,10,12,14').split(',').map(Number);
const out = existsSync('casts.json') ? JSON.parse(readFileSync('casts.json')) : {};
for (const d of DISTANCES) {
  for (const cyc of [1,2,3]) {
    const key = `${d}m_c${cyc}`;
    if (out[key]) { console.log('skip', key); continue; }
    console.log('=== ', key, '===');
    const r = spawnSync('node', ['run_target.mjs', String(d), String(cyc)],
                        {stdio:'inherit'});
    if (existsSync('best_target.json'))
      out[key] = JSON.parse(readFileSync('best_target.json'));
    writeFileSync('casts.json', JSON.stringify(out, null, 1));
  }
}
console.log('\ndone —', Object.keys(out).length, 'cells in casts.json');
