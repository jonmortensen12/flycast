import * as S from './sim.mjs';
import { poseFn, BOUNDS, READY_PITCH, layoutReady, duration } from './opt.mjs';
import { Quaternion, Vector3 } from './three-stub.mjs';
import { readFileSync, writeFileSync } from 'fs';
const {target,P}=JSON.parse(readFileSync('best_target.json'));
const DEG=Math.PI/180, XAX=new Vector3(1,0,0), q=new Quaternion();
S.applyPreset_(S.PHYSICAL); S.P.waterModel=0; S.P.nodeLen=0.20; S.P.leadNode=0.06;
S.setLineOut(P.lineOut); S.rebuildSpacing(); S.rebuildRod(); S.rebuildMasses();
const pose=poseFn(P);
q.setFromAxisAngle(XAX,READY_PITCH*DEG);
S.setHand(0.28,1.15,0.10,q); S.resetCast(); layoutReady(); S.setLineHand(0.05,1.05,0.15,0);
const DT=1/180, EVERY=5, tip=(S.RN-1)*3, frames=[];
const T=duration(P);
let prevPitch=READY_PITCH;
for(let k=0;k*DT<T;k++){
  const t=k*DT, p=pose(t);
  q.setFromAxisAngle(XAX,p.pitch*DEG);
  S.setHand(0.28,1.15+p.slide*p.st,0.10+p.slide*p.ct,q);
  S.stepInputs(DT); S.physics(DT);
  if(S.state().blewUp){S.clearBlewUp();break;}
  const om=p.phase==='settle'?0:Math.abs(p.pitch-prevPitch)/DT; prevPitch=p.pitch;
  if(k%EVERY) continue;
  const s=S.state();
  const rod=[]; for(let i=0;i<S.RN;i++) rod.push(+S.rpos[i*3].toFixed(3),+S.rpos[i*3+1].toFixed(3),+S.rpos[i*3+2].toFixed(3));
  const last=Math.min(s.nAct-1,Math.floor(S.idxAt(s.lineOut))), line=[];
  for(let j=0;j<70;j++){
    const arc=s.lineOut*j/69, f=Math.min(last-1e-3,Math.max(0,S.idxAt(arc)));
    const a=Math.max(0,Math.floor(f)),b=Math.min(last,a+1),u=f-a;
    line.push(+(S.pos[a*3]+(S.pos[b*3]-S.pos[a*3])*u).toFixed(3),
              +(S.pos[a*3+1]+(S.pos[b*3+1]-S.pos[a*3+1])*u).toFixed(3),
              +(S.pos[a*3+2]+(S.pos[b*3+2]-S.pos[a*3+2])*u).toFixed(3));
  }
  let bend=0;
  for(let i=1;i<S.RN-1;i++){
    const a=(i-1)*3,b=i*3,c=(i+1)*3;
    const ux=S.rpos[b]-S.rpos[a],uy=S.rpos[b+1]-S.rpos[a+1],uz=S.rpos[b+2]-S.rpos[a+2];
    const vx=S.rpos[c]-S.rpos[b],vy=S.rpos[c+1]-S.rpos[b+1],vz=S.rpos[c+2]-S.rpos[b+2];
    const ul=Math.hypot(ux,uy,uz)||1,vl=Math.hypot(vx,vy,vz)||1;
    bend+=Math.acos(Math.max(-1,Math.min(1,(ux*vx+uy*vy+uz*vz)/(ul*vl))));
  }
  let ux=S.rpos[3]-S.rpos[0],uy=S.rpos[4]-S.rpos[1],uz=S.rpos[5]-S.rpos[2];
  const ul=Math.hypot(ux,uy,uz)||1;
  const defl=Math.hypot(S.rpos[tip]-(S.rpos[0]+ux/ul*S.ROD_LEN),S.rpos[tip+1]-(S.rpos[1]+uy/ul*S.ROD_LEN),S.rpos[tip+2]-(S.rpos[2]+uz/ul*S.ROD_LEN));
  frames.push({t:+t.toFixed(3),phase:p.phase,pitch:Math.round(p.pitch),
    bend:+(bend*180/Math.PI).toFixed(1),
    tipSp:+Math.hypot(S.rvel[tip],S.rvel[tip+1],S.rvel[tip+2]).toFixed(2),
    omega:Math.round(om), defl:+(defl*100).toFixed(0), stretch:1.0,
    iter:S.getSolver().ITER, lineOut:+s.lineOut.toFixed(2), rod, line});
}
writeFileSync('frames.json',JSON.stringify([{
  name:'BEST CAST SO FAR — target 10 m',
  note:'miss 0.88 m, impact 3.9 m/s, butt 588 deg/s, tip deflection 147 cm (too high).',
  fps:180/EVERY, linePts:70, rodPts:S.RN, frames,
  target:[target.x,0,target.z]}]));
console.log('frames',frames.length);
