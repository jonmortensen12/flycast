/* Offline stroke optimiser.
 *
 * Finds the easiest hand motion that puts the fly softly on a target, and is
 * forgiving enough that a human reproducing it approximately still lands close.
 *
 * Runs OFFLINE. One evaluation is a full physics cast (~0.45 s at 20 cm node
 * spacing), and a search needs several hundred, so this is not something the
 * headset can do on demand. The plan is to run this over a grid of targets and
 * ship the resulting control points as a table the app interpolates.
 *
 * Parameterisation: 9 numbers, all with direct physical meaning, so the result
 * is inspectable and cannot contain a wrist-snap exploit.
 *
 *   lineOut     m    line outside the tiptop at the start (the app sets this up
 *                    when the player presses the "set up cast" button)
 *   startDeg    deg  rod pitch at rest, 0 = horizontal downrange, 90 = vertical
 *   arcBack     deg  angular sweep of the back stroke
 *   tBack       s    duration of the back stroke
 *   pause       s    hold at the back stop
 *   arcFwd      deg  sweep of the forward stroke
 *   tFwd        s    duration of the forward stroke
 *   strokeLen   m    hand translation over the stroke
 *   handTilt    deg  tilt of the hand's straight-line path above horizontal
 *
 * Effort is peak butt angular velocity and peak hand speed, both normalised
 * against published expert values, so "easy" means "well inside what a person
 * comfortably does" rather than "small numbers".
 */
import * as S from './sim.mjs';
import { Quaternion, Vector3 } from './three-stub.mjs';

const DEG = Math.PI / 180;
const XAX = new Vector3(1, 0, 0);
const _q = new Quaternion();

export const BOUNDS = [
  ['lineOut', 4.0, 16.0],
  ['arcBack', 45, 135],
  ['tBack', 0.18, 0.65],
  ['pause', 0.25, 1.60],
  ['arcFwd', 45, 135],
  ['tFwd', 0.16, 0.60],
  ['strokeLen', 0.20, 1.50],
  ['handTilt', -20, 35],
  ['cycles', 1.0, 3.49],     // false-cast cycles before the delivery (rounded)
];
const clampVec = v => v.map((x, i) => Math.max(BOUNDS[i][1], Math.min(BOUNDS[i][2], x)));
const asObj = v => Object.fromEntries(BOUNDS.map((b, i) => [b[0], v[i]]));

/* velocity shapes: accelerate smoothly, then check hard. The stop is what
   throws the loop, so the profile must not decelerate into the endpoint. */
const N = 240;
function shape(fn) {
  const v = new Float64Array(N + 1);
  let s = 0;
  for (let i = 0; i <= N; i++) { v[i] = fn(i / N); s += v[i]; }
  const mean = s / (N + 1);
  const d = new Float64Array(N + 1);
  let a = 0;
  for (let i = 0; i <= N; i++) { d[i] = a / (N * mean); a += v[i]; }
  return { d, peak: Math.max(...v) / mean };
}
const ROT = shape(x => (x <= 0.88 ? Math.pow(x / 0.88, 2.0) : 1 - (x - 0.88) / 0.12));
const TRN = shape(x => Math.pow(x, 1.4) * Math.pow(Math.max(0, 1 - x), 2.6));
const at = (p, x) => {
  const f = Math.max(0, Math.min(N - 1e-9, x * N));
  const i = Math.floor(f);
  return p[i] + (p[i + 1] - p[i]) * (f - i);
};

const SETTLE = 0.6, HOLD = 2.6;   // HOLD is a cap; we exit the moment it lands

/* READY POSITION.
   The old setup laid every extra metre of line out downrange, so more lineOut
   meant the fly started closer to the target. The optimiser found that instantly
   and "solved" a 10 m cast with a hand twitch that dragged the fly across the
   water. Extra line must cost something.
   Now the rod starts at 45 degrees forward with the fly on the water directly
   below the tip, and any line beyond the tip-to-fly hang is coiled in a pile at
   the fly's feet. Extra line is now slack that has to be picked up and shot,
   which is what it is in reality. */
export const READY_PITCH = 45;
export function layoutReady() {
  const T = (S.RN - 1) * 3;
  const tx = S.rpos[T], ty = S.rpos[T + 1], tz = S.rpos[T + 2];
  const gy = S.filmY(tx, tz, 0);
  const hang = Math.max(0.5, ty - gy);
  const st = S.state();
  const coil = Math.max(0, st.lineOut - hang);
  const n = st.nAct;
  for (let i = 0; i < n; i++) {
    const a = S.sArc(i), p = i * 3;
    if (a <= coil) {
      /* loose pile on the ground: a slow spiral, not a tight knot the solver
         would spend the first half second fighting its way out of */
      const u = coil > 1e-6 ? a / coil : 0;
      const th = u * Math.PI * 5.0, r = 0.16 + 0.20 * u;
      S.pos[p] = tx + Math.cos(th) * r;
      S.pos[p + 1] = gy + 0.012 + 0.02 * u;
      S.pos[p + 2] = tz + Math.sin(th) * r;
    } else if (a <= st.lineOut) {
      const u = (a - coil) / Math.max(hang, 1e-6);
      S.pos[p] = tx; S.pos[p + 1] = gy + (ty - gy) * u; S.pos[p + 2] = tz;
    }
    if (a <= st.lineOut) { S.vel[p] = 0; S.vel[p + 1] = 0; S.vel[p + 2] = 0; }
  }
}

/* A cast is one or more false-cast cycles followed by the delivery. From the
   ready position most of the line is piled at the fly's feet, and a single
   stroke cannot straighten it — which is exactly why real casters false cast to
   extend line before delivering. The optimiser now gets to choose how many. */
export const nCycles = P => Math.max(1, Math.min(3, Math.round(P.cycles)));
export const cycleT = P => P.tBack + P.pause + P.tFwd + P.pause;

export function poseFn(P) {
  const nc = nCycles(P), cy = cycleT(P);
  const back = READY_PITCH + P.arcBack;
  const ct = Math.cos(P.handTilt * DEG), st = Math.sin(P.handTilt * DEG);
  return t => {
    let pitch, slide, phase;
    if (t < SETTLE) return { pitch: READY_PITCH, slide: 0, phase: 'settle', ct, st };
    const u = t - SETTLE;
    const k = Math.floor(u / cy);
    const last = k >= nc - 1;
    const l = u - k * cy;
    if (k >= nc) { return { pitch: back - P.arcFwd, slide: 0, phase: 'hold', ct, st }; }
    if (l < P.tBack) {
      const x = l / P.tBack;
      pitch = READY_PITCH + P.arcBack * at(ROT.d, x);
      slide = P.strokeLen * at(TRN.d, x); phase = 'back';
    } else if (l < P.tBack + P.pause) { pitch = back; slide = P.strokeLen; phase = 'pause'; }
    else if (l < P.tBack + P.pause + P.tFwd) {
      const x = (l - P.tBack - P.pause) / P.tFwd;
      pitch = back - P.arcFwd * at(ROT.d, x);
      slide = P.strokeLen * (1 - at(TRN.d, x));
      phase = last ? 'fwd' : 'false';
    } else { pitch = back - P.arcFwd; slide = 0; phase = last ? 'hold' : 'fpause'; }
    return { pitch, slide, phase, ct, st };
  };
}
export const duration = P => SETTLE + nCycles(P) * cycleT(P) + HOLD;

const DT = 1 / 180;
export function evaluate(P, target, opts = {}) {
  S.applyPreset_(S.PHYSICAL);
  S.P.waterModel = 0;
  S.P.nodeLen = opts.nodeLen || 0.20;
  S.P.leadNode = opts.leadNode || 0.06;
  S.setLineOut(P.lineOut);
  S.rebuildSpacing(); S.rebuildRod(); S.rebuildMasses();

  const pose = poseFn(P);
  _q.setFromAxisAngle(XAX, READY_PITCH * DEG);
  S.setHand(0.28, 1.15, 0.10, _q);
  S.resetCast();
  layoutReady();
  S.setLineHand(0.05, 1.05, 0.15, 0);

  const T = duration(P);
  const n = Math.round(T / DT);
  const tip = (S.RN - 1) * 3;
  let peakW = 0, peakHand = 0, prevPitch = READY_PITCH, prevSlide = 0;
  let landed = null, maxDefl = 0;
  /* A real cast sends the fly behind the caster, high, and back out again. A
     twitch does none of those, so measure them and require them. */
  let backMost = -9, flyPath = 0, flyHigh = -9, loopSeen = 0;
  let px = S.pos[0], py = S.pos[1], pz = S.pos[2];

  for (let k = 0; k < n; k++) {
    const t = k * DT;
    const p = pose(t);
    _q.setFromAxisAngle(XAX, p.pitch * DEG);
    S.setHand(0.28, 1.15 + p.slide * p.st, 0.10 + p.slide * p.ct, _q);
    S.stepInputs(DT);
    S.physics(DT);
    if (S.state().blewUp) { S.clearBlewUp(); return null; }

    if (p.phase !== 'settle') {
      const w = Math.abs(p.pitch - prevPitch) / DT;
      if (w > peakW) peakW = w;
      const hv = Math.abs(p.slide - prevSlide) / DT;
      if (hv > peakHand) peakHand = hv;
      let ux = S.rpos[3] - S.rpos[0], uy = S.rpos[4] - S.rpos[1], uz = S.rpos[5] - S.rpos[2];
      const ul = Math.hypot(ux, uy, uz) || 1;
      const d = Math.hypot(S.rpos[tip] - (S.rpos[0] + ux / ul * S.ROD_LEN),
                           S.rpos[tip + 1] - (S.rpos[1] + uy / ul * S.ROD_LEN),
                           S.rpos[tip + 2] - (S.rpos[2] + uz / ul * S.ROD_LEN));
      if (d > maxDefl) maxDefl = d;
    }
    prevPitch = p.pitch; prevSlide = p.slide;

    {
      const fx = S.pos[0], fy = S.pos[1], fz = S.pos[2];
      flyPath += Math.hypot(fx - px, fy - py, fz - pz);
      px = fx; py = fy; pz = fz;
      if (fz > backMost) backMost = fz;
      if (fy > flyHigh) flyHigh = fy;
      /* loop: during the forward stroke the fly is still behind the rod tip,
         i.e. the line has folded and is rolling out rather than being dragged */
      if (p.phase === 'fwd' && fz > S.rpos[tip + 2] + 0.5 && fy > 0.5) loopSeen = 1;
    }

    if (!landed && p.phase === 'hold') {
      const film = S.filmY(S.pos[0], S.pos[2], t);
      if (S.pos[1] < film + 0.03) {
        landed = { x: S.pos[0], z: S.pos[2],
                   v: Math.hypot(S.vel[0], S.vel[1], S.vel[2]), t };
        break;            /* nothing after touchdown affects the score */
      }
    }
  }
  if (!landed) return null;
  return { landed, peakW, peakHand, maxDefl, backMost, flyPath, flyHigh, loopSeen };
}

/* Cost. Accuracy and softness are hard requirements; effort is what we actually
   minimise once those are met. Deflection outside the physical band for a 9 ft
   5wt is penalised so the optimiser cannot "solve" the problem by folding the
   blank in half. */
/* Two stages. Stage 1 barely cares about effort — it just has to find casts
   that reach the target at all, because from a cold start most candidates
   collapse and score the failure constant, which tells the search nothing.
   Stage 2 then minimises effort among casts that already land. */
export function cost(P, target, opts = {}) {
  const r = evaluate(P, target, opts);
  if (!r) return 60;
  const miss = Math.hypot(r.landed.x - target.x, r.landed.z - target.z);
  const effort = peakEffort(r);
  const HAND_Z = 0.10;

  /* Hard feasibility gates. A 9 ft 5wt deflects 45-75 cm in an expert cast and
     an expert butt turns at 300-355 deg/s. Anything far outside that is not a
     motion a person can make, so it is rejected outright rather than traded
     against accuracy — which is how the optimiser previously "solved" a 10 m
     cast with 1073 deg/s and a blank folded double. */
  const infeasible =
      Math.max(0, r.peakW - 520) * 0.05
    + Math.max(0, r.peakHand - 2.2) * 3.0
    + Math.max(0, r.maxDefl - 0.90) * 12
    + Math.max(0, 0.30 - r.maxDefl) * 4
    + Math.max(0, 1.6 - (r.backMost - HAND_Z)) * 2.5
    + Math.max(0, 1.8 - r.flyHigh) * 1.5
    + (r.loopSeen ? 0 : 1.6);

  /* Accuracy is a CONSTRAINT, not a term. Outside tolerance nothing else
     matters; inside it, effort and a soft landing are all that is being
     minimised, so precision can never be bought with a violent hand. */
  const TOL = opts.tol || 1.0;
  if (miss > TOL) return 12 + 2.5 * (miss - TOL) + infeasible;
  const soft = Math.max(0, r.landed.v - 1.6);
  return effort + 2.0 * soft + infeasible + 0.4 * miss;
}

/* a physically sensible starting point beats the middle of the parameter box:
   expert arc and timing, with line out scaled to the target distance */
export function seedFor(target) {
  const d = Math.hypot(target.x - 0.28, target.z - 0.10);
  /* Seeded from a measured sweep, not from expert medium-cast values. Arc turned
   out to dominate reach: at 62 deg this cast travelled 1.4 m, at 95 deg it went
   10.8 m with everything else identical. Stroke length scales with line length,
   which is the standard instruction-book rule, so scale the seed with distance. */
  return [Math.max(5.5, Math.min(15.5, d + 1.2)),
          100, 0.45, 0.95, 100, 0.38, Math.min(1.2, 0.35 + d * 0.055), 8, 2.0];
}
export const peakEffort = r => r.peakW / 340 + r.peakHand / 1.4;

/* Forgiveness: score under injected human noise rather than at the nominal
   point, so broad shallow valleys beat fragile optima. Timing wobble and stop
   angle drift are what a real caster actually varies. */
const NOISE = [
  { tBack: 0, pause: 0, arcFwd: 0, tFwd: 0 },
  { tBack: 0.03, pause: 0.13, arcFwd: 5, tFwd: 0.03 },
  { tBack: -0.03, pause: -0.13, arcFwd: -5, tFwd: -0.03 },
];
export function robustCost(v, target, opts, nSamples = 3) {
  const base = asObj(clampVec(v));
  let worst = 0, sum = 0;
  for (let i = 0; i < nSamples; i++) {
    const d = NOISE[i % NOISE.length];
    const P = { ...base };
    for (const k in d) P[k] = Math.max(0.05, P[k] + d[k]);
    const c = cost(P, target, opts);
    sum += c; if (c > worst) worst = c;
  }
  return 0.7 * (sum / nSamples) + 0.3 * worst;
}
